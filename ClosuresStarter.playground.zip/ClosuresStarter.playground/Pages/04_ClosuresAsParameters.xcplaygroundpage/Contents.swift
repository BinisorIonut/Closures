import Foundation
//: [Previous](@previous)
//: ## 4. Closures as parameters
/*:
 Because closures can be used just like strings and integers, you can pass them into functions. The syntax for this can hurt your brain at first, so we’re going to take it slow.\
First, here’s our basic *driving()* closure again:
*/
let driving = {
    print("I'm driving in my car")
}
/*:
 If we wanted to pass that closure into a function so it can be run inside that function, we would specify the parameter type as () -> Void. That means “accepts no parameters, and returns Void” – Swift’s way of saying “nothing”.

 So, we can write a travel() function that accepts different kinds of traveling actions, and prints a message before and after:
*/

<#Write a function that accepts a closure#>

//: [Next](@next)
